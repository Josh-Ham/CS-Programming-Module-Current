from logger import log_infomation
from logger import log_error
from logger import log_warning

def test_log_infomation():
    log_infomation('Test infomation')

def test_log_error():
    log_error('Test error')

def test_log_warning():
    log_warning('Test warning')
